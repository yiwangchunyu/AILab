//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� lab03.rc ʹ��
//
#define IDC_MYICON                      2
#define IDD_WYJLAB05SDK_DIALOG          102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WYJLAB05SDK                 107
#define IDI_SMALL                       108
#define IDC_WYJLAB05SDK                 109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDB_BITMAP3                     131
#define IDB_BITMAP4                     132
#define IDB_BITMAP5                     133
#define IDB_BITMAP6                     134
#define IDC_CURSOR1                     135
#define IDR_MENU1                       136
#define IDI_ICON1                       137
#define IDR_MENU2                       138
#define IDD_DIALOG1                     139
#define IDD_DIALOG2                     140
#define IDR_ACCELERATOR1                141
#define IDC_CHECK1                      1000
#define IDC_CHECK2                      1001
#define IDC_CHECK3                      1002
#define IDC_RADIO1                      1003
#define IDC_RADIO2                      1004
#define IDC_RADIO3                      1005
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_ABOUT_PROGRAMINFORMATION     32781
#define ID_LANGUAGE_32782               32782
#define ID_LANGUAGE_ENGLISH             32783
#define ID_CURSOR_CURSOR1               32784
#define ID_CURSOR_CURSOR2               32785
#define ID_CURSOR_CURSOR3               32786
#define ID_DIALOG_MODAL                 32787
#define ID_DIALOG_MODAL32788            32788
#define ID_DIALOG_MODAL32789            32789
#define ID_FILE_EXIT                    32790
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
