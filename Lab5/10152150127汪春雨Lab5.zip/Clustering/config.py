DATA_FILE = 'data/Lab5data.xlsx'
